package com.example.apiretro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {
    EditText emailEt,passwordEt;
    Button loginBtn;
    TextView signUpTv;
    String email,password;
    APIInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        try {
            emailEt = findViewById(R.id.emailEt);
            passwordEt = findViewById(R.id.passwordEt);
            loginBtn = findViewById(R.id.loginBtn);
            signUpTv = findViewById(R.id.signUpTv);
            loginButtonClick();
            signUpTextViewClick();

        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public void loginButtonClick(){
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkValidation()){
                    loginRetrofit2Api(email, password);
                }
            }
        });
    }
    public void signUpTextViewClick(){
        signUpTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,SignUp.class));
            }
        });
    }
    private void loginRetrofit2Api(String userId, String password) {
        try {
            final EmployeeLoginRes login = new EmployeeLoginRes(userId, password);
            Call<EmployeeLoginRes> call1 = apiInterface.checkEmployee(login);
            call1.enqueue(new Callback<EmployeeLoginRes>() {
                @Override
                public void onResponse(Call<EmployeeLoginRes> call, Response<EmployeeLoginRes> response) {
                    EmployeeLoginRes loginResponse = response.body();

                     if (loginResponse != null) {

                        String responseCode = loginResponse.getResponseCode();
                        if (responseCode != null && responseCode.equals("404")) {
                            Toast.makeText(Login.this, "Invalid Login Details \n Please try again", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Login.this, "Welcome " + loginResponse.getEmployeeName(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<EmployeeLoginRes> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), "on Failure", Toast.LENGTH_SHORT).show();
                    call.cancel();
                }
            });
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    public boolean checkValidation() {
        email = emailEt.getText().toString();
        password = passwordEt.getText().toString();

        if (emailEt.getText().toString().trim().equals("")) {
             Toast.makeText(this, "email Cannot be left blank", Toast.LENGTH_SHORT).show();
            return false;
        } else if (passwordEt.getText().toString().trim().equals("")) {
             Toast.makeText(this, "password Cannot be left blank", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}