package com.example.apiretro;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface APIInterface {
    @POST("api/Employees/GetEmployeeByEmailAndPasswordCustomApi")
    Call<EmployeeLoginRes> checkEmployee(@Body EmployeeLoginRes login);

    @POST("api/Employees/GetEmployees")
    Call<EmployeeLoginRes> createEmployee(@Body EmployeeLoginRes login);


}
